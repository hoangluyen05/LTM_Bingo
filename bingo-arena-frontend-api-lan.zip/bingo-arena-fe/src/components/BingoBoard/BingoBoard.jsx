import { getCompletedLines } from "../../utils/bingo";
import "./BingoBoard.css";

export default function BingoBoard({
    board = [],
    calledNumbers = [],
    canPlay = false,
    onSelect,
}) {
    if (board.length !== 25) {
        return <p>Đang tải bảng Bingo...</p>;
    }

    const completedLines = getCompletedLines(
        board,
        calledNumbers
    );

    const completedCells = new Set(
        completedLines.flat()
    );

    return (
        <div className="bingo-board-wrapper">
            <div className="bingo-board-grid">
                {["B", "I", "N", "G", "O"].map((letter) => (
                    <div className="bingo-board-heading" key={letter}>
                        {letter}
                    </div>
                ))}

                {board.map((number, index) => {
                    const marked = calledNumbers.includes(number);
                    const completed = completedCells.has(index);

                    return (
                        <button
                            key={number}
                            type="button"
                            className={[
                                "bingo-board-cell",
                                marked ? "marked" : "",
                                completed ? "completed" : "",
                            ].join(" ")}
                            disabled={!canPlay || marked}
                            onClick={() => onSelect?.(number)}
                            aria-label={`Số ${number}`}
                            aria-pressed={marked}
                        >
                            {number}
                        </button>
                    );
                })}
            </div>

            <div className="bingo-board-legend">
                <span>⬛ Chưa gọi</span>
                <span>🟪 Đã gọi</span>
                <span>🟩 Đường Bingo</span>
            </div>
        </div>
    );
}