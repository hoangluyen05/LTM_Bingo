import { apiRequest } from "./api";
export function login(data) {
  return apiRequest("/auth/login", { method: "POST", body: { username: data.username.trim(), password: data.password } });
}
export function register(data) {
  return apiRequest("/auth/register", { method: "POST", body: {
    username: data.username.trim(), password: data.password,
    displayName: (data.displayName || data.username).trim(),
  } });
}
