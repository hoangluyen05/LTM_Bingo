// API host is derived from the browser URL so the same build works on both LAN PCs.
const explicit = (import.meta.env.VITE_API_BASE_URL || "").trim();
const BASE_URL = explicit || "/api";

export async function apiRequest(path, { method = "GET", body } = {}) {
  const token = sessionStorage.getItem("bingo_access_token");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${BASE_URL}${path}`, {
      method,
      headers: {
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: controller.signal,
    });
    const text = await response.text();
    let data;
    try { data = text ? JSON.parse(text) : null; }
    catch { throw new Error("Phản hồi từ Server không phải JSON hợp lệ."); }
    if (!response.ok) {
      const error = new Error(data?.message || `Lỗi HTTP ${response.status}`);
      error.status = response.status;
      error.code = data?.code || "HTTP_ERROR";
      error.fieldErrors = data?.fieldErrors || {};
      throw error;
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("Server phản hồi quá lâu.");
    if (error instanceof TypeError) throw new Error(`Không thể kết nối Backend tại ${BASE_URL}. Kiểm tra IP, CORS và firewall.`);
    throw error;
  } finally { clearTimeout(timeout); }
}
